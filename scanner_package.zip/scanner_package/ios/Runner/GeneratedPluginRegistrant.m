//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <native_device_orientation/NativeDeviceOrientationPlugin.h>
#import <qr_mobile_vision/QrMobileVisionPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [NativeDeviceOrientationPlugin registerWithRegistrar:[registry registrarForPlugin:@"NativeDeviceOrientationPlugin"]];
  [QrMobileVisionPlugin registerWithRegistrar:[registry registrarForPlugin:@"QrMobileVisionPlugin"]];
}

@end
